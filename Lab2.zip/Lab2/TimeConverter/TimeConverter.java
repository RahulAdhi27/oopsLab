package TimeConverter;

public class TimeConverter {

    public double hoursToMinutes(double hours) {
        return hours*60;
    }

    public double minutesToHours(double minutes) {
        return minutes*0.01667;
    }

    public double hoursToSeconds(double hours) {
        return hours*3600;
    }

    public double secondsToHours(double seconds) {
        return seconds/3600;
    }
}

