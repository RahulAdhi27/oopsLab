import java.util.Scanner;
import CurrencyConverter.CurrencyConverter;
import DistanceConverter.DistanceConverter;
import TimeConverter.TimeConverter;

public class Converter{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		CurrencyConverter currencyConverter = new CurrencyConverter();
		DistanceConverter distanceConverter = new DistanceConverter();
		TimeConverter timeConverter = new TimeConverter();
		
		System.out.println("Choose which converter: ");
		System.out.println("1. Currency Converter");
		System.out.println("2. Distance Converter");
		System.out.println("3. Time Converter");
		System.out.print("Choose which option you want: ");
		
		int choice1 = sc.nextInt();
		int choice2;
		double amount;
		double time;
		double distance;
		switch (choice1){
			case 1:
                		System.out.println("Currency Conversion:");
                		System.out.println("1. Dollar to INR");
                		System.out.println("2. INR to Dollar");
                		System.out.println("3. Euro to INR");
                		System.out.println("4. INR to Euro");
                		System.out.println("5. Yen to INR");
                		System.out.println("6. INR to Yen");
                		System.out.print("Enter your choice: ");
                		
                		choice2 = sc.nextInt();
                		
                		switch(choice2){
                			case 1:
                		
                				System.out.print("Enter the amount to convert: ");
                				amount = sc.nextDouble();
                				System.out.println(amount+" dollars = "+currencyConverter.dollarToInr(amount)+" INR");
                				break;
                			case 2:
                			
                				System.out.print("Enter the amount to convert: ");
                				amount = sc.nextDouble();
                				System.out.println(amount+" INR = "+currencyConverter.inrToDollar(amount)+" Dollars");
                				break;
                			case 3:
                			
                				System.out.print("Enter the amount to convert: ");
                				amount = sc.nextDouble();
                				System.out.println(amount+" Euros = "+currencyConverter.euroToInr(amount)+" INR");
                				break;
                  			case 4:
                  			
                				System.out.print("Enter the amount to convert: ");
                				amount = sc.nextDouble();
                				System.out.println(amount+" INR = "+currencyConverter.inrToEuro(amount)+" Euro");
                				break;
                     			case 5:
                     		
                				System.out.print("Enter the amount to convert: ");
                				amount = sc.nextDouble();
                				System.out.println(amount+" yen = "+currencyConverter.yenToInr(amount)+" INR");
                				break;
                    			case 6:
                    
                				System.out.print("Enter the amount to convert: ");
                				amount = sc.nextDouble();
                				System.out.println(amount+" INR = "+currencyConverter.inrToYen(amount)+" yen");
                				break;
                			default:
                				System.out.println("Invalid choice for currency converter");
                		}
                		break;
			case 2:
                		System.out.println("Distance Conversion:");
                		System.out.println("1. Meter to Kilometer");
                		System.out.println("2. Kilometer to Meter");
                		System.out.println("3. Miles to Kilometer");
                		System.out.println("4. Kilometer to Miles");
                		System.out.print("Enter your choice: ");
                		choice2 = sc.nextInt();
                		
                		switch(choice2){
                			case 1:
                		
                				System.out.print("Enter the distance to convert: ");
                				distance = sc.nextDouble();
                				System.out.println(distance+" meter = "+distanceConverter.meterToKm(distance)+" km");
                				break;
                			case 2:
                
                				System.out.print("Enter the distance to convert: ");
                				distance = sc.nextDouble();
                				System.out.println(distance+" km = "+distanceConverter.kmToMeter(distance)+" meter");
                				break;
                			case 3:
               
                				System.out.print("Enter the distance to convert: ");
                				distance = sc.nextDouble();
                				System.out.println(distance+" miles = "+distanceConverter.milesToKm(distance)+" km");
                				break;
                  			case 4:
                  
                				System.out.print("Enter the distance to convert: ");
                				distance = sc.nextDouble();
                				System.out.println(distance+" km = "+distanceConverter.kmToMiles(distance)+" miles");
                				break;
                  			default:
                				System.out.println("Invalid choice for currency converter");
                		}
                		break;
			case 3:
                		System.out.println("Distance Conversion:");
                		System.out.println("1. Hours to Minutes");
                		System.out.println("2. Minutes to Hours");
                		System.out.println("3. Hours to Seconds");
                		System.out.println("4. Seconds to Hours");
                		System.out.print("Enter your choice: ");
                		choice2 = sc.nextInt();
                		
                		switch(choice2){
                			case 1:
           
                				System.out.print("Enter the time to convert: ");
                				time = sc.nextDouble();
                				System.out.println(time+" hours = "+timeConverter.hoursToMinutes(time)+" minutes");
                				break;
                			case 2:
                	
                				System.out.print("Enter the time to convert: ");
                				time = sc.nextDouble();
                				System.out.println(time+" minutes = "+timeConverter.minutesToHours(time)+" hours");
                				break;
                			case 3:
      
                				System.out.print("Enter the time to convert: ");
                				time = sc.nextDouble();
                				System.out.println(time+" hours = "+timeConverter.hoursToSeconds(time)+" seconds");
                				break;
                  			case 4:
                  
                				System.out.print("Enter the time to convert: ");
                				time = sc.nextDouble();
                				System.out.println(time+" seconds = "+timeConverter.secondsToHours(time)+" hours");
                				break;
                  			default:
                				System.out.println("Invalid choice for currency converter");
                		}
                		break;
                	default:
                		System.out.println("Invalid choice for conversion type!");
		
		}
		
		sc.close();
	
	}
}














































