package CurrencyConverter;
public class CurrencyConverter{
	public static double dollarToInr(double dollars){
		return dollars*86.5;
	}
	public static double inrToDollar(double inr){
		return inr*0.012;
	}
	public static double euroToInr(double euro){
		return euro*101.6;
	}
	public static double inrToEuro(double inr){
		return inr*0.0098;
	}
	public static double yenToInr(double yen){
		return yen*0.59;
	}
	public static double inrToYen(double inr){
		return inr*1.70;
	}
}
