package DistanceConverter;
public class DistanceConverter{
    public double meterToKm(double meters) {
        return meters*0.001;
    }

    public double kmToMeter(double km) {
        return km*1000;
    }

    public double milesToKm(double miles) {
        return miles*1.6;
    }

    public double kmToMiles(double km) {
        return km*0.62;
    }
}
